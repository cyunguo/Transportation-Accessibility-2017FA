Transportation Model
Last update: 2018/01/29
Author: Yunguo Cai

MATLAB version: R2016b

Main file descriptions:
assessibility.m 			Main file for calculating the assessilibilities
model_set_up.m 				Construct models for the city with specified inputs
random_xy_pos.m 			Get a random (x,y) position with specified ipnuts
travel_dist.m 				Calculating the travel distantce between two points
travel_time.m 				Calculating the travel time between two points
Density Comparision 		Files modified accordingly for the section of density comparision of the documentation
Location Comparision 		Files modified accordingly for the section of location comparision of the documentation
Skill Comparision 			Files modified accordingly for the section of skill comparision of the documentation
Trans Comparision 			Files modified accordingly for the section of transportation comparision of the documentation
